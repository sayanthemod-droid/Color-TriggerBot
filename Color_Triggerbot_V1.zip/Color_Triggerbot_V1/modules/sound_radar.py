"""
Sound Direction Radar
- Listens to stereo game audio in real time
- Detects left/right/front/back sound direction
- Draws a radar circle with direction arrows on screen
"""

import cv2
import numpy as np
import threading
import time
import winsound

try:
    import sounddevice as sd
    SOUND_AVAILABLE = True
except ImportError:
    SOUND_AVAILABLE = False


SAMPLE_RATE  = 44100
BLOCK_SIZE   = 1024
RADAR_RADIUS = 60
DECAY        = 0.85      # how fast arrows fade


class SoundRadar:
    def __init__(self, sw, sh, cx, cy, overlay):
        self.sw       = sw
        self.sh       = sh
        self.enabled  = False
        self._lock    = threading.Lock()
        self._stop    = threading.Event()

        # Direction magnitudes (0-1)
        self.left     = 0.0
        self.right    = 0.0
        self.volume   = 0.0

        # Radar position — top right
        self.rx = sw - 90
        self.ry = 90

    def toggle(self):
        self.enabled = not self.enabled
        freq = 1000 if self.enabled else 400
        threading.Thread(target=winsound.Beep,args=(freq,100),daemon=True).start()
        print(f"[SoundRadar] {'ON' if self.enabled else 'OFF'}")

    def start(self):
        if not SOUND_AVAILABLE:
            print("[SoundRadar] sounddevice not installed — radar disabled")
            print("  Run: uv run --with sounddevice python main.py")
            return
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self):
        self._stop.set()

    def _audio_callback(self, indata, frames, time_info, status):
        if not self.enabled:
            return
        # indata shape: (frames, channels)
        if indata.shape[1] >= 2:
            l_vol = float(np.abs(indata[:, 0]).mean())
            r_vol = float(np.abs(indata[:, 1]).mean())
        else:
            l_vol = r_vol = float(np.abs(indata[:, 0]).mean())

        total = l_vol + r_vol + 1e-9
        with self._lock:
            self.left   = (self.left  * DECAY + (l_vol / total) * (1 - DECAY))
            self.right  = (self.right * DECAY + (r_vol / total) * (1 - DECAY))
            self.volume = min((l_vol + r_vol) * 80, 1.0)

    def _loop(self):
        while not self._stop.is_set():
            if not self.enabled:
                time.sleep(0.2)
                continue

            try:
                with sd.InputStream(
                    samplerate=SAMPLE_RATE,
                    blocksize=BLOCK_SIZE,
                    channels=2,
                    callback=self._audio_callback
                ):
                    while self.enabled and not self._stop.is_set():
                        time.sleep(0.05)
            except Exception as e:
                print(f"[SoundRadar] Audio error: {e}")
                time.sleep(0.5)

    def draw(self, canvas, cx, cy):
        if not self.enabled or not SOUND_AVAILABLE:
            return

        rx = self.rx
        ry = self.ry
        r  = RADAR_RADIUS

        with self._lock:
            left   = self.left
            right  = self.right
            volume = self.volume

        # Background circle
        cv2.circle(canvas, (rx,ry), r, (40,40,40), -1)
        cv2.circle(canvas, (rx,ry), r, (255,200,0), 1)

        # Cross lines
        cv2.line(canvas,(rx-r,ry),(rx+r,ry),(60,60,60),1)
        cv2.line(canvas,(rx,ry-r),(rx,ry+r),(60,60,60),1)

        # Left arrow
        l_len = int(r * 0.8 * left * 2)
        if l_len > 4:
            col = (int(255*volume), 100, 255)
            cv2.arrowedLine(canvas,(rx,ry),(rx-l_len,ry),col,2,tipLength=0.3)

        # Right arrow
        r_len = int(r * 0.8 * right * 2)
        if r_len > 4:
            col = (int(255*volume), 100, 255)
            cv2.arrowedLine(canvas,(rx,ry),(rx+r_len,ry),col,2,tipLength=0.3)

        # Label
        cv2.putText(canvas,"SOUND",(rx-22,ry+r+14),
                    cv2.FONT_HERSHEY_SIMPLEX,0.35,(255,200,0),1)

        # Volume ring
        if volume > 0.05:
            vr = int(r * 0.3 * volume)
            cv2.circle(canvas,(rx,ry),max(vr,2),(0,255,200),1)
