"""
Transparent fullscreen overlay window — shared by all modules
Black pixels = transparent (colorkey)
"""

import cv2
import numpy as np
import ctypes

WS_EX_TOPMOST     = 0x00000008
WS_EX_TRANSPARENT = 0x00000020
WS_EX_LAYERED     = 0x00080000
WS_EX_TOOLWINDOW  = 0x00000080
GWL_EXSTYLE       = -20
LWA_COLORKEY      = 0x00000001


class OverlayWindow:
    def __init__(self, sw, sh):
        self.sw   = sw
        self.sh   = sh
        self.name = "valorant_suite_overlay"
        self.canvas = np.zeros((self.sh, self.sw, 3), dtype=np.uint8)
        self._make_window()

    def _make_window(self):
        cv2.namedWindow(self.name, cv2.WINDOW_NORMAL)
        cv2.setWindowProperty(self.name, cv2.WND_PROP_FULLSCREEN,
                              cv2.WINDOW_FULLSCREEN)
        hwnd  = ctypes.windll.user32.FindWindowW(None, self.name)
        style = (WS_EX_TOPMOST | WS_EX_TRANSPARENT |
                 WS_EX_LAYERED  | WS_EX_TOOLWINDOW)
        ctypes.windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
        ctypes.windll.user32.SetLayeredWindowAttributes(
            hwnd, 0x00000000, 0, LWA_COLORKEY)
        HWND_TOPMOST = ctypes.c_void_p(-1)
        ctypes.windll.user32.SetWindowPos(
            hwnd, HWND_TOPMOST, 0, 0, self.sw, self.sh,
            0x0002 | 0x0001 | 0x0020)

    def render(self, trigger, recoil, radar, clipper, cx, cy):
        canvas = self.canvas
        canvas.fill(0)

        # Each module draws itself onto the canvas
        trigger.draw(canvas, cx, cy)
        recoil.draw(canvas)
        radar.draw(canvas, cx, cy)
        clipper.draw(canvas)

        # Global HUD bottom-left
        self._draw_hud(canvas, trigger, recoil, radar, clipper)

        cv2.imshow(self.name, canvas)
        cv2.waitKey(1)

    def _draw_hud(self, canvas, trigger, recoil, radar, clipper):
        items = [
            ("F1 TRIGGER",   trigger.enabled,  (0, 255, 100)),
            ("F2 RECOIL",    recoil.enabled,   (0, 200, 255)),
            ("F3 RADAR",     radar.enabled,    (255, 200, 0)),
            ("F4 CLIPS",     clipper.enabled,  (200, 100, 255)),
        ]
        y = self.sh - 20
        x = 10
        for label, state, col in items:
            color = col if state else (60, 60, 60)
            cv2.putText(canvas, label, (x, y),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.38, color, 1)
            x += 130
        cv2.putText(canvas, "F7=QUIT  F10=ALL",
                    (x, y), cv2.FONT_HERSHEY_SIMPLEX, 0.38, (100, 100, 100), 1)

    def close(self):
        cv2.destroyAllWindows()
