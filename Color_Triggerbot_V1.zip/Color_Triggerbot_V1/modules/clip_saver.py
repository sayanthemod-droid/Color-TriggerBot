"""
Auto Clip Saver
- Keeps a rolling 20-second screen buffer
- Detects kill/event by: bright red/white flash OR volume spike
- Auto-saves clip to clips/ folder when event detected
- F4 toggle, shows recording indicator
"""

import cv2
import numpy as np
import mss
import threading
import time
import os
import winsound
from collections import deque
from datetime import datetime


BUFFER_SECONDS = 12
CAPTURE_FPS    = 12
JPEG_QUALITY   = 45
CLIPS_DIR      = os.path.join(os.path.dirname(__file__), "..", "clips")

# Kill flash detection — bright red/white flash in center area
FLASH_THRESHOLD = 220     # pixel brightness
FLASH_AREA_FRAC = 0.3     # center 30% of screen


class ClipSaver:
    def __init__(self, sw, sh, monitor):
        self.sw        = sw
        self.sh        = sh
        self.monitor   = monitor
        self.enabled   = False
        self._lock     = threading.Lock()
        self._stop     = threading.Event()
        self._buffer   = deque()   # deque of (timestamp, frame_bytes)
        self._saving   = False
        self._last_save= 0
        self._indicator= 0         # flash counter for UI dot
        self.clip_count= 0

        os.makedirs(CLIPS_DIR, exist_ok=True)

    def toggle(self):
        self.enabled = not self.enabled
        freq = 1000 if self.enabled else 400
        threading.Thread(target=winsound.Beep,args=(freq,100),daemon=True).start()
        print(f"[ClipSaver] {'ON' if self.enabled else 'OFF'}")

    def start(self):
        threading.Thread(target=self._capture_loop, daemon=True).start()
        threading.Thread(target=self._detect_loop,  daemon=True).start()

    def stop(self):
        self._stop.set()

    def _capture_loop(self):
        sct    = mss.mss()
        mon    = self.monitor
        delay  = 1.0 / CAPTURE_FPS
        maxbuf = BUFFER_SECONDS * CAPTURE_FPS
        region = {"top": mon["top"], "left": mon["left"],
                  "width": self.sw, "height": self.sh}

        while not self._stop.is_set():
            t0 = time.perf_counter()
            if self.enabled:
                raw = sct.grab(region)
                # Store as small JPEG bytes to save RAM
                frame = cv2.cvtColor(np.array(raw), cv2.COLOR_BGRA2BGR)
                small = cv2.resize(frame, (self.sw//2, self.sh//2))
                _, buf = cv2.imencode('.jpg', small,
                                      [cv2.IMWRITE_JPEG_QUALITY, JPEG_QUALITY])
                with self._lock:
                    self._buffer.append((time.time(), buf))
                    # Trim old frames
                    while len(self._buffer) > maxbuf:
                        self._buffer.popleft()

            dt = time.perf_counter() - t0
            if delay > dt:
                time.sleep(delay - dt)

    def _detect_loop(self):
        sct    = mss.mss()
        mon    = self.monitor
        delay  = 0.1   # check every 100ms

        cx  = self.sw // 2
        cy  = self.sh // 2
        hw  = int(self.sw * FLASH_AREA_FRAC / 2)
        hh  = int(self.sh * FLASH_AREA_FRAC / 2)

        region = {
            "top":    mon["top"]  + cy - hh,
            "left":   mon["left"] + cx - hw,
            "width":  hw * 2,
            "height": hh * 2,
        }

        while not self._stop.is_set():
            if self.enabled:
                raw   = sct.grab(region)
                frame = cv2.cvtColor(np.array(raw), cv2.COLOR_BGRA2BGR)

                # Detect red kill flash
                hsv   = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
                red1  = cv2.inRange(hsv, np.array([0,150,200]),  np.array([10,255,255]))
                red2  = cv2.inRange(hsv, np.array([170,150,200]),np.array([180,255,255]))
                red   = cv2.bitwise_or(red1, red2)
                r_pct = np.count_nonzero(red) / red.size

                # Save if significant red flash
                now = time.time()
                if r_pct > 0.08 and now - self._last_save > 5:
                    self._last_save = now
                    self._indicator = 30
                    threading.Thread(target=self._save_clip,
                                     daemon=True).start()

            time.sleep(delay)

    def _save_clip(self):
        if self._saving:
            return
        self._saving = True

        # Wait 2 more seconds to capture aftermath
        time.sleep(2)

        with self._lock:
            frames = list(self._buffer)

        if not frames:
            self._saving = False
            return

        ts   = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(CLIPS_DIR, f"clip_{ts}.avi")

        h, w = self.sh // 2, self.sw // 2
        out  = cv2.VideoWriter(path,
                               cv2.VideoWriter_fourcc(*'XVID'),
                               CAPTURE_FPS, (w, h))

        for (_, buf) in frames:
            frame = cv2.imdecode(buf, cv2.IMREAD_COLOR)
            out.write(frame)
        out.release()

        self.clip_count += 1
        winsound.Beep(800, 200)
        print(f"[ClipSaver] Saved: {path}")
        self._saving = False

    def draw(self, canvas):
        if not self.enabled:
            return

        # Recording dot
        col = (0,0,255) if self._indicator > 0 else (0,180,0)
        if self._indicator > 0:
            self._indicator -= 1
        cv2.circle(canvas, (self.sw-15, 15), 6, col, -1)
        cv2.putText(canvas, f"REC  clips:{self.clip_count}",
                    (self.sw-120, 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38,
                    (0,180,0), 1)
