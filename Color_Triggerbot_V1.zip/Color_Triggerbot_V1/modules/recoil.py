"""
Recoil Pattern Recorder
- Hold LEFT CLICK while shooting → records mouse movement
- Shows your actual spray pattern vs a clean dot
- Press R to reset / clear pattern
- Draws live spray graph in bottom-right corner
"""

import cv2
import numpy as np
import threading
import time
import winsound
import ctypes
from ctypes import wintypes


class RecoilRecorder:
    def __init__(self, sw, sh, cx, cy, overlay):
        self.sw      = sw
        self.sh      = sh
        self.enabled = False
        self._lock   = threading.Lock()
        self._stop   = threading.Event()
        self.points  = []          # list of (dx, dy) from spray start
        self._origin = None        # mouse pos when fire started
        self._firing = False

        # Graph panel config
        self.panel_x  = sw - 220
        self.panel_y  = sh - 270
        self.panel_w  = 200
        self.panel_h  = 240
        self.scale    = 3          # pixels per mouse unit

    def toggle(self):
        self.enabled = not self.enabled
        freq = 1000 if self.enabled else 400
        threading.Thread(target=winsound.Beep,args=(freq,100),daemon=True).start()
        print(f"[Recoil] {'ON' if self.enabled else 'OFF'}")

    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self):
        self._stop.set()

    def _get_mouse_pos(self):
        pt = wintypes.POINT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return pt.x, pt.y

    def _is_lmb_down(self):
        return ctypes.windll.user32.GetAsyncKeyState(0x01) & 0x8000

    def _loop(self):
        delay = 1 / 60   # poll at 60hz
        import keyboard as kb
        while not self._stop.is_set():
            if self.enabled:
                firing = bool(self._is_lmb_down())

                if firing and not self._firing:
                    # Fire started — record origin
                    self._origin = self._get_mouse_pos()
                    self._firing = True

                elif firing and self._firing:
                    # Accumulate delta
                    mx, my = self._get_mouse_pos()
                    ox, oy = self._origin
                    dx = mx - ox
                    dy = my - oy
                    with self._lock:
                        self.points.append((dx, dy))

                elif not firing:
                    self._firing = False

                # R key = reset
                if kb.is_pressed('r'):
                    with self._lock:
                        self.points.clear()
                    time.sleep(0.3)

            time.sleep(delay)

    def draw(self, canvas):
        if not self.enabled:
            return

        px = self.panel_x
        py = self.panel_y
        pw = self.panel_w
        ph = self.panel_h

        # Panel background (dark, semi-visible via non-black color)
        cv2.rectangle(canvas, (px,py), (px+pw, py+ph), (20,20,20), -1)
        cv2.rectangle(canvas, (px,py), (px+pw, py+ph), (80,80,80),  1)

        cv2.putText(canvas, "RECOIL PATTERN", (px+5, py+16),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, (0,200,255), 1)
        cv2.putText(canvas, "R=reset", (px+pw-55, py+16),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.32, (100,100,100), 1)

        # Centre dot (zero point)
        cx0 = px + pw // 2
        cy0 = py + ph // 2
        cv2.circle(canvas, (cx0, cy0), 3, (0,255,0), -1)

        # Draw spray points
        with self._lock:
            pts = list(self.points)

        prev = None
        for i,(dx,dy) in enumerate(pts):
            sx = cx0 + int(dx * self.scale)
            sy = cy0 + int(dy * self.scale)
            # Color fades red→yellow as spray goes on
            ratio = i / max(len(pts),1)
            col   = (0, int(255*(1-ratio)), 255)
            if prev:
                cv2.line(canvas, prev, (sx,sy), col, 1)
            cv2.circle(canvas,(sx,sy),2,col,-1)
            prev = (sx,sy)

        # Shot count
        cv2.putText(canvas, f"Shots: {len(pts)}", (px+5, py+ph-6),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.32, (150,150,150), 1)
