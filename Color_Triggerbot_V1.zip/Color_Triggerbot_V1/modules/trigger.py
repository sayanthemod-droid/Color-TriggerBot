"""
Trigger Bot Module
- Detects purple enemy outline
- Shows visual tracking to nearest target (green line)
- Presses K when crosshair is on enemy head zone
"""

import cv2
import numpy as np
import mss
import keyboard
import threading
import time
import winsound
import ctypes
from ctypes import wintypes
import math

# Try to import pynput for hardware-level mouse control
try:
    from pynput.mouse import Controller as MouseController
    PYNPUT_AVAILABLE = True
    mouse_controller = MouseController()
except ImportError:
    PYNPUT_AVAILABLE = False
    mouse_controller = None

# Fallback to Windows API
user32 = ctypes.windll.user32


PURPLE_LOWER = np.array([130, 100, 100], dtype=np.uint8)  # Wider range to catch head
PURPLE_UPPER = np.array([170, 255, 255], dtype=np.uint8)

MIN_AREA     = 150         # Lower to detect head separately
MIN_ASP      = 0.3         # Allow wider aspect ratios
MAX_ASP      = 5.0         # Allow taller boxes
MERGE_GAP    = 40          # Larger gap to merge head with body
CAPTURE_FPS  = 24
CAPTURE_SCALE = 0.5
CAPTURE_FOV  = 320

# Smooth aim settings
SMOOTH_FACTOR = 0.25       # How much to move toward target each frame (0.0-1.0)
MAX_MOVE_SPEED = 12        # Maximum pixels to move per frame
AIM_AT_HEAD = True         # Aim at head (top 8%) or center
HEAD_OFFSET = 0.08         # Where on the target to aim (0.0=top, 1.0=bottom, 0.08=head)

BOX_COLOR    = (255, 255, 255)
HEAD_COLOR   = (0, 200, 255)
FOV_SIZE     = 300          # half-size of white FOV square
KEY          = 'k'

try:
    cv2.setNumThreads(1)
except Exception:
    pass

EXCLUDE = [
    (0.0,  0.0,  0.22, 0.32),   # minimap top-left
    (0.0,  0.85, 1.0,  1.0 ),   # bottom HUD
    (0.30, 0.0,  0.70, 0.10),   # top timer/buy phase text
    (0.65, 0.0,  1.0,  0.30),   # top-right scoreboard + radar
    (0.55, 0.18, 1.0,  0.85),   # right side — weapon skin + combat report
    (0.0,  0.0,  0.10, 1.0 ),   # far left edge
]


def _merge(boxes, gap=30):
    if not boxes:
        return []
    merged = True
    while merged:
        merged = False
        result = []
        used   = [False] * len(boxes)
        for i in range(len(boxes)):
            if used[i]:
                continue
            x1,y1,w1,h1 = boxes[i]
            ex1,ey1 = x1+w1, y1+h1
            for j in range(i+1, len(boxes)):
                if used[j]:
                    continue
                x2,y2,w2,h2 = boxes[j]
                ex2,ey2 = x2+w2, y2+h2
                if x2-gap<ex1 and ex2+gap>x1 and y2-gap<ey1 and ey2+gap>y1:
                    nx,ny   = min(x1,x2), min(y1,y2)
                    nex,ney = max(ex1,ex2), max(ey1,ey2)
                    boxes[i] = [nx,ny,nex-nx,ney-ny]
                    x1,y1,w1,h1 = boxes[i]
                    ex1,ey1 = x1+w1, y1+h1
                    used[j] = True
                    merged  = True
            result.append(list(boxes[i]))
        boxes = result
    return [tuple(b) for b in boxes]


class TriggerBot:
    def __init__(self, sw, sh, cx, cy, overlay):
        self.sw      = sw
        self.sh      = sh
        self.cx      = cx
        self.cy      = cy
        self.enabled = True
        self.visual_enabled = True  # Toggle visual overlay
        self.boxes   = []
        self.locked  = False
        self.nearest_target = None  # Store nearest target info
        self._held   = False
        self._lock   = threading.Lock()
        self._stop   = threading.Event()

    def toggle(self):
        self.enabled = not self.enabled
        freq = 1000 if self.enabled else 400
        threading.Thread(target=winsound.Beep, args=(freq,100), daemon=True).start()
        if not self.enabled:
            self._release()
        print(f"[Trigger] {'ON' if self.enabled else 'OFF'}")
    
    def toggle_visual(self):
        """Toggle visual overlay on/off"""
        self.visual_enabled = not self.visual_enabled
        freq = 1200 if self.visual_enabled else 600
        threading.Thread(target=winsound.Beep, args=(freq,80), daemon=True).start()
        print(f"[Trigger Visual] {'ON' if self.visual_enabled else 'OFF'}")

    def start(self):
        if not PYNPUT_AVAILABLE:
            print("[WARNING] pynput not installed - mouse movement will NOT work!")
            print("          Install with: pip install pynput")
        threading.Thread(target=self._loop, daemon=True).start()

    def stop(self):
        self._stop.set()
        self._release()

    def _press(self):
        if not self._held:
            keyboard.press(KEY)
            self._held = True

    def _release(self):
        if self._held:
            keyboard.release(KEY)
            self._held = False
    
    def _move_mouse_to_target(self, target_x, target_y):
        """Smoothly move mouse toward target using pynput (hardware simulation)"""
        try:
            if PYNPUT_AVAILABLE and mouse_controller:
                # Get current mouse position
                current_x, current_y = mouse_controller.position
                
                # Calculate distance to target
                dx = target_x - current_x
                dy = target_y - current_y
                distance = math.sqrt(dx*dx + dy*dy)
                
                # Don't move if already very close
                if distance < 3:
                    return
                
                # Calculate smooth movement
                move_x = dx * SMOOTH_FACTOR
                move_y = dy * SMOOTH_FACTOR
                
                # Limit max speed
                move_dist = math.sqrt(move_x*move_x + move_y*move_y)
                if move_dist > MAX_MOVE_SPEED:
                    scale = MAX_MOVE_SPEED / move_dist
                    move_x *= scale
                    move_y *= scale
                
                # Apply movement using pynput (hardware-level)
                new_x = current_x + move_x
                new_y = current_y + move_y
                mouse_controller.position = (new_x, new_y)
            else:
                # Fallback: No movement if pynput not available
                pass
                
        except Exception as e:
            pass  # Silently ignore errors
    
    def _find_nearest_target(self, boxes):
        """Find the target closest to crosshair center"""
        if not boxes:
            return None
        
        nearest = None
        min_dist = float('inf')
        
        for (x, y, w, h) in boxes:
            # Calculate target point (head position or center)
            if AIM_AT_HEAD:
                target_x = x + w // 2
                target_y = y + int(h * HEAD_OFFSET)
            else:
                target_x = x + w // 2
                target_y = y + h // 2
            
            # Distance from crosshair to target point
            dx = target_x - self.cx
            dy = target_y - self.cy
            dist = math.sqrt(dx*dx + dy*dy)
            
            if dist < min_dist:
                min_dist = dist
                nearest = (target_x, target_y, dist)
        
        return nearest

    def _loop(self):
        sct    = mss.mss()
        mon    = sct.monitors[1]
        delay  = 1.0 / CAPTURE_FPS
        cap_x = max(0, self.cx - CAPTURE_FOV)
        cap_y = max(0, self.cy - CAPTURE_FOV)
        cap_w = min(self.sw, self.cx + CAPTURE_FOV) - cap_x
        cap_h = min(self.sh, self.cy + CAPTURE_FOV) - cap_y
        region = {
            "top": mon["top"] + cap_y,
            "left": mon["left"] + cap_x,
            "width": cap_w,
            "height": cap_h,
        }
        small_size = (
            max(1, int(cap_w * CAPTURE_SCALE)),
            max(1, int(cap_h * CAPTURE_SCALE)),
        )
        scaled_min_area = max(20, int(MIN_AREA * CAPTURE_SCALE * CAPTURE_SCALE))
        k1 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        k2 = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2, 2))

        while not self._stop.is_set():
            t0 = time.perf_counter()
            if self.enabled:
                raw   = sct.grab(region)
                frame = cv2.cvtColor(np.array(raw), cv2.COLOR_BGRA2BGR)
                small = cv2.resize(frame, small_size,
                                   interpolation=cv2.INTER_NEAREST)

                hsv  = cv2.cvtColor(small, cv2.COLOR_BGR2HSV)
                mask = cv2.inRange(hsv, PURPLE_LOWER, PURPLE_UPPER)

                mask = cv2.dilate(mask, k1, iterations=3)  # More dilation to connect head+body
                mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k2, iterations=3)

                cnts,_ = cv2.findContours(mask, cv2.RETR_EXTERNAL,
                                          cv2.CHAIN_APPROX_SIMPLE)
                raw_b  = []
                for c in cnts:
                    if cv2.contourArea(c) < scaled_min_area:
                        continue
                    x,y,w,h = cv2.boundingRect(c)
                    if not (MIN_ASP <= h/max(w,1) <= MAX_ASP):
                        continue
                    raw_b.append([
                        int(x / CAPTURE_SCALE) + cap_x,
                        int(y / CAPTURE_SCALE) + cap_y,
                        int(w / CAPTURE_SCALE),
                        int(h / CAPTURE_SCALE),
                    ])

                boxes  = _merge(raw_b, MERGE_GAP)
                
                # Find nearest target for visual tracking only (no mouse movement)
                nearest = self._find_nearest_target(boxes)
                if nearest:
                    self.nearest_target = nearest
                else:
                    self.nearest_target = None
                
                # Check if crosshair is on head zone for key press
                locked = any(
                    x <= self.cx <= x+w and
                    self.cy <= y + int(h*0.25) and
                    self.cy >= y
                    for (x,y,w,h) in boxes
                )

                with self._lock:
                    self.boxes  = boxes
                    self.locked = locked

                self._press() if locked else self._release()
            else:
                with self._lock:
                    self.boxes  = []
                    self.locked = False
                self._release()

            dt = time.perf_counter() - t0
            if delay > dt:
                time.sleep(delay - dt)

    def draw(self, canvas, cx, cy):
        # Show minimal indicator if visual is off
        if not self.visual_enabled:
            if self.enabled:
                status_text = "AIM:ON" if self.locked else "AIM:--"
                color = (0, 255, 0) if self.locked else (100, 100, 100)
                cv2.putText(canvas, status_text, (10, 60),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.4, color, 1)
            return
        
        if not self.enabled:
            return

        with self._lock:
            boxes  = list(self.boxes)
            locked = self.locked

        # White FOV square
        cv2.rectangle(canvas,
                      (cx - FOV_SIZE, cy - FOV_SIZE),
                      (cx + FOV_SIZE, cy + FOV_SIZE),
                      (255, 255, 255), 1)

        for (x,y,w,h) in boxes:
            col = (30,30,255) if locked else BOX_COLOR
            # Corner box
            cl = max(min(w,h)//4, 5)
            cv2.rectangle(canvas,(x,y),(x+w,y+h),col,1)
            for (ax,ay),(bx,by),(cx2,cy2) in [
                ((x,y),(x+cl,y),(x,y+cl)),
                ((x+w,y),(x+w-cl,y),(x+w,y+cl)),
                ((x,y+h),(x+cl,y+h),(x,y+h-cl)),
                ((x+w,y+h),(x+w-cl,y+h),(x+w,y+h-cl)),
            ]:
                cv2.line(canvas,(ax,ay),(bx,by),col,2)
                cv2.line(canvas,(ax,ay),(cx2,cy2),col,2)

            # Head zone
            hh = max(int(h*0.25),4)
            cv2.rectangle(canvas,(x,y),(x+w,y+hh),HEAD_COLOR,1)

        # Draw line to nearest target
        if self.nearest_target:
            target_x, target_y, distance = self.nearest_target
            cv2.line(canvas, (cx, cy), (target_x, target_y), (0, 255, 0), 1)
            cv2.circle(canvas, (target_x, target_y), 4, (0, 255, 255), -1)
            # Show distance
            cv2.putText(canvas, f"{int(distance)}px", (target_x+10, target_y-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0, 255, 255), 1)

        # Crosshair
        dc = (30,30,255) if locked else (160,160,160)
        cv2.circle(canvas,(cx,cy),4,dc,-1)
        cv2.line(canvas,(cx-12,cy),(cx+12,cy),dc,1)
        cv2.line(canvas,(cx,cy-12),(cx,cy+12),dc,1)

        if locked:
            cv2.putText(canvas,"HEAD LOCKED",(cx+15,cy-10),
                        cv2.FONT_HERSHEY_SIMPLEX,0.55,(30,30,255),2)
        elif self.nearest_target:
            cv2.putText(canvas,"TRACKING",(cx+15,cy-10),
                        cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,255,0),2)
