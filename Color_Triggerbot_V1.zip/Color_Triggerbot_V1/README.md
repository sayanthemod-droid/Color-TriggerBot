<div align="center">

```
 ██████╗ ██████╗ ██╗      ██████╗ ██████╗     ████████╗██████╗ ██╗ ██████╗  ██████╗ ███████╗██████╗ ██████╗  ██████╗ ████████╗
██╔════╝██╔═══██╗██║     ██╔═══██╗██╔══██╗    ╚══██╔══╝██╔══██╗██║██╔════╝ ██╔════╝ ██╔════╝██╔══██╗██╔══██╗██╔═══██╗╚══██╔══╝
██║     ██║   ██║██║     ██║   ██║██████╔╝       ██║   ██████╔╝██║██║  ███╗██║  ███╗█████╗  ██████╔╝██████╔╝██║   ██║   ██║   
██║     ██║   ██║██║     ██║   ██║██╔══██╗       ██║   ██╔══██╗██║██║   ██║██║   ██║██╔══╝  ██╔══██╗██╔══██╗██║   ██║   ██║   
╚██████╗╚██████╔╝███████╗╚██████╔╝██║  ██║       ██║   ██║  ██║██║╚██████╔╝╚██████╔╝███████╗██║  ██║██████╔╝╚██████╔╝   ██║   
 ╚═════╝ ╚═════╝ ╚══════╝ ╚═════╝ ╚═╝  ╚═╝       ╚═╝   ╚═╝  ╚═╝╚═╝ ╚═════╝  ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝    ╚═╝   
```

<h3>⚡ V1 — Precision. Speed. Control. ⚡</h3>

[![Made By](https://img.shields.io/badge/Made%20By-roxrays-blueviolet?style=for-the-badge&logo=github)](https://github.com/roxrays)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue?style=for-the-badge&logo=python)](https://www.python.org/)
[![Platform](https://img.shields.io/badge/Platform-Windows-informational?style=for-the-badge&logo=windows)](https://www.microsoft.com/windows)
[![Status](https://img.shields.io/badge/Status-Active-brightgreen?style=for-the-badge)]()
[![Version](https://img.shields.io/badge/Version-1.0.0-orange?style=for-the-badge)]()

---

</div>

## 📌 Overview

> **Color Triggerbot V1** is a high-performance, modular color-detection triggerbot built in Python.  
> Designed for precision and low latency, it features a clean modular architecture with support for  
> recoil control, sound radar, in-game overlay, and automatic clip saving.

---

## ✨ Features

| Module | Description |
|---|---|
| 🎯 **Triggerbot** | Instant color-based trigger detection with configurable sensitivity |
| 🔫 **Recoil Control** | Smooth, humanized recoil compensation patterns |
| 🔊 **Sound Radar** | Directional audio cue detection and visualization |
| 🖥️ **Overlay** | Real-time transparent in-game HUD overlay |
| 🎬 **Clip Saver** | Automatic highlight and clip recording |

---

## 📁 Project Structure

```
Color_Triggerbot_V1/
│
├── main.py                 # Entry point
├── color_bot.py            # Core color detection engine
├── run.bat                 # Quick launch script
├── requirements.txt        # Python dependencies
│
└── modules/
    ├── trigger.py          # Trigger logic
    ├── recoil.py           # Recoil compensation
    ├── sound_radar.py      # Sound radar module
    ├── overlay.py          # Overlay renderer
    ├── clip_saver.py       # Clip recording
    └── __init__.py
```

---

## ⚙️ Installation

**1. Clone or download the repository**

```bash
git clone https://github.com/roxrays/Color_Triggerbot_V1.git
cd Color_Triggerbot_V1
```

**2. Install dependencies**

```bash
pip install -r requirements.txt
```

---

## 🚀 Usage

**Option A — Batch launcher (recommended)**
```bash
run.bat
```

**Option B — Direct Python**
```bash
python main.py
```

---

## 🛠️ Requirements

- Python `3.10+`
- Windows OS
- See `requirements.txt` for all package dependencies

---

## ⚠️ Disclaimer

> This project is intended for **educational and research purposes only**.  
> Usage in online games may violate terms of service. The author holds no responsibility  
> for any misuse of this software.

---

<div align="center">

## 👤 Credits

<br>

```
╔══════════════════════════════════════╗
║                                      ║
║         Made with ❤️ by              ║
║                                      ║
║   ██████╗  ██████╗ ██╗  ██╗         ║
║   ██╔══██╗██╔═══██╗╚██╗██╔╝         ║
║   ██████╔╝██║   ██║ ╚███╔╝          ║
║   ██╔══██╗██║   ██║ ██╔██╗          ║
║   ██║  ██║╚██████╔╝██╔╝ ██╗         ║
║   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝         ║
║                                      ║
║           r o x r a y s             ║
║                                      ║
╚══════════════════════════════════════╝
```

<br>

[![GitHub](https://img.shields.io/badge/GitHub-roxrays-181717?style=for-the-badge&logo=github)](https://github.com/roxrays)

<br>

*© 2026 roxrays — All Rights Reserved*

---

*Color Triggerbot V1 — Built for precision.*

</div>
